import './App.css';
import {Films} from './components/Films/Films';

function App() {
  return (
    <div className="App">
     <Films />
     <img className="img1"/>
     <img className="img2"/>
    </div>

  );
}

export default App;
